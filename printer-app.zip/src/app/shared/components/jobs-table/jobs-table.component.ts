import { Component, OnInit } from '@angular/core'

@Component({
  selector: 'app-jobs-table',
  templateUrl: './jobs-table.component.html',
  styleUrls: ['./jobs-table.component.scss']
})
export class JobsTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
